#!/system/bin/sh
# Robust late_start_service script for OLED2LCD module
# Replaces the original service.sh with POSIX-safe code, retries the call and logs results.
# Log file: /data/adb/modules/oled2lcd/service.log

MODID="oled2lcd"
LOG="/data/adb/modules/${MODID}/service.log"

log() {
  # prefix timestamp if possible
  ts="$(date '+%F %T' 2>/dev/null || printf '%s' "$(date 2>/dev/null)")"
  echo "${ts} $*" >> "${LOG}" 2>/dev/null
}

# ensure log exists and is writable
mkdir -p "$(dirname "${LOG}")" 2>/dev/null
touch "${LOG}" 2>/dev/null

log "service.sh starting"

# wait until device reports boot completed
if command -v getprop >/dev/null 2>&1; then
  log "waiting for sys.boot_completed..."
  while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
    sleep 1
  done
  log "boot_completed=1"
else
  log "getprop not found, skipping boot wait"
fi

# extra short sleep to allow services to stabilize
sleep 20
log "additional sleep done, attempting SurfaceFlinger call"

# prepare to call service; try multiple times
CALL_CMD="service call SurfaceFlinger 1022 f 1.5"
MAX_ATTEMPTS=6
SLEEP_BETWEEN=5
attempt=1
success=0

# Ensure 'service' command exists; otherwise try 'toolbox' or 'toybox' fallback (very rare)
if ! command -v service >/dev/null 2>&1 ; then
  log "warning: 'service' command not found in PATH"
fi

while [ "${attempt}" -le "${MAX_ATTEMPTS}" ]; do
  log "attempt ${attempt}/${MAX_ATTEMPTS}: running: ${CALL_CMD}"
  # run the command and capture output/exit
  /system/bin/sh -c "${CALL_CMD}" >> "${LOG}" 2>&1
  rc=$?
  if [ "${rc}" -eq 0 ]; then
    log "SurfaceFlinger call succeeded (rc=${rc}) on attempt ${attempt}"
    success=1
    break
  else
    log "SurfaceFlinger call failed (rc=${rc}) on attempt ${attempt}; sleeping ${SLEEP_BETWEEN}s"
    sleep "${SLEEP_BETWEEN}"
  fi
  attempt=$((attempt + 1))
done

if [ "${success}" -ne 1 ]; then
  log "All attempts failed. As fallback, trying a short looped approach with smaller waits."
  # fallback: try a few light attempts
  i=0
  while [ $i -lt 10 ]; do
    /system/bin/sh -c "${CALL_CMD}" >> "${LOG}" 2>&1
    rc=$?
    if [ "${rc}" -eq 0 ]; then
      log "Fallback SurfaceFlinger call succeeded at fallback iteration ${i}"
      success=1
      break
    fi
    sleep 2
    i=$((i+1))
  done
fi

if [ "${success}" -eq 1 ]; then
  log "Finished successfully."
else
  log "Giving up after retries. Please check log for details."
fi

exit 0