# OLED2LCD (Old name: Saturation)
A simple self-updateable Magisk and KernelSU module for setting the saturation of the panel to 2x or 1.5x
  
Preview by GSMArena:  
![](https://fdn.gsmarena.com/imgroot/news/17/10/sunday-debate-vol-1/-728w2/gsmarena_006.jpg?raw=true)
