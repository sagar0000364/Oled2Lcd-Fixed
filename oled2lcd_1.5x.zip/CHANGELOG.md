For support this project: [Patreon](https://avalibeyaz.com/patreon)  
--------------

## v1.3.2
- Try to use KernelSU's new feature "webroot html UI" (thanks to [0x0021](https://github.com/0x0021))
- Changed versionCode structure to xxyyzz (for example for v2.0.1 is 020001, not 201 now)
  
## v1.3.1  
- Added 1 more different variant (2.0 and 1.5) to releases
- Fixed some typos
- Fixed module over module issue  

## v1.3.0 (removed)
- Added 1 more different variant (2.0 and 1.5) to releases
  
## v1.2.2
- Added KernelSU support    
  
## v1.2.1
- Added create&release workflow  
  
## v1.2.0  
- First version by me :)  
- Renamed saturation to oled2lcd  
- Changed versioning structure from vx.y to vx.y.z
- Added update feature  
- Addded changelog  
  
## v1.1  
- This release is from original module developer, Draco. So there is no any notes about changes  
  
## v1.0  
- This version also created by original developer, Draco. Probably it was initial release  
